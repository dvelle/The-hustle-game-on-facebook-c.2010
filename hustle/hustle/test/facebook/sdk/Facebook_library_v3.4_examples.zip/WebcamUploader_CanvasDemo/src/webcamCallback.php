<fb:add-section-button section="profile"/>

<hr />
<!-- 
Set the swfsrc and imgsrc to an URL on your server.
-->

<fb:swf id='facebookApp'
		swfsrc='webcamUploader.swf'
		imgsrc='webcamUploader.jpg'
		swfbgcolor='006599'
		width='214' 
		height='255' />